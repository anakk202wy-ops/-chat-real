const socket = io();

const $ = (id) => document.getElementById(id);
const welcome = $("welcome");
const chat = $("chat");
const nameInput = $("name");
const roomInput = $("room");
const error = $("error");
const messages = $("messages");
const messageInput = $("message");
const form = $("form");
const roomLabel = $("roomLabel");
const presence = $("presence");
const typing = $("typing");
const toast = $("toast");

let username = "";
let currentRoom = "";
let typingTimer;

const urlRoom = new URLSearchParams(location.search).get("room");
if (urlRoom) roomInput.value = urlRoom;

function showError(text) { error.textContent = text || ""; }

function addMessage(msg) {
  const el = document.createElement("div");
  el.className = "msg" + (msg.user === username ? " mine" : "");

  const meta = document.createElement("div");
  meta.className = "meta";
  meta.textContent = `${msg.user} • ${new Date(msg.time).toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"})}`;

  const text = document.createElement("div");
  text.className = "text";
  text.textContent = msg.text;

  el.append(meta, text);
  messages.appendChild(el);
  messages.scrollTop = messages.scrollHeight;
}

function addSystem(text) {
  const el = document.createElement("div");
  el.className = "system";
  el.textContent = text;
  messages.appendChild(el);
  messages.scrollTop = messages.scrollHeight;
}

function enterRoom(result) {
  username = result.username;
  currentRoom = result.roomId;
  welcome.classList.add("hidden");
  chat.classList.remove("hidden");
  roomLabel.textContent = `Sala ${currentRoom}`;
  messages.innerHTML = "";
  (result.messages || []).forEach(addMessage);
  history.replaceState({}, "", `?room=${encodeURIComponent(currentRoom)}`);
  messageInput.focus();
}

$("create").onclick = () => {
  showError("");
  const name = nameInput.value.trim();
  if (!name) return showError("Digite um apelido.");
  socket.emit("create-room", { name }, enterRoom);
};

$("join").onclick = () => {
  showError("");
  const name = nameInput.value.trim();
  const roomId = roomInput.value.trim();
  if (!name) return showError("Digite um apelido.");
  if (!roomId) return showError("Digite o código da sala.");
  socket.emit("join-room", { roomId, name }, (result) => {
    if (!result.ok) return showError(result.error);
    enterRoom(result);
  });
};

form.onsubmit = (e) => {
  e.preventDefault();
  const value = messageInput.value.trim();
  if (!value) return;
  socket.emit("message", value);
  messageInput.value = "";
  socket.emit("typing", false);
};

messageInput.addEventListener("input", () => {
  socket.emit("typing", true);
  clearTimeout(typingTimer);
  typingTimer = setTimeout(() => socket.emit("typing", false), 700);
});

$("copy").onclick = async () => {
  const invite = `${location.origin}${location.pathname}?room=${encodeURIComponent(currentRoom)}`;
  try {
    await navigator.clipboard.writeText(invite);
    toast.textContent = "Link de convite copiado!";
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 1800);
  } catch {
    prompt("Copie o link de convite:", invite);
  }
};

$("leave").onclick = () => {
  location.href = location.pathname;
};

socket.on("message", addMessage);
socket.on("system", addSystem);
socket.on("presence", (count) => {
  presence.textContent = `${count} online`;
});
socket.on("typing", ({ user, isTyping }) => {
  typing.textContent = isTyping ? `${user} está digitando...` : "";
});
